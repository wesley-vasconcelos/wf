import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatButtonModule, MatCheckboxModule, MatInputModule, MatSelectModule,
        MatFormFieldModule, MatDatepickerModule, MatDatepickerIntl, MatNativeDateModule,
        MAT_DATE_LOCALE, MatExpansionModule, MatIconModule} from '@angular/material';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { HomeComponent } from './pages/home/home.component';
import { NavbarComponent } from './shared/navbar/navbar.component';
import { FooterComponent } from './shared/footer/footer.component';
import { PhotosComponent } from './shared/photos/photos.component';
import { LogoComponent } from './shared/logo/logo.component';
import { FormContactComponent } from './shared/form-contact/form-contact.component';
import { ContactComponent } from './pages/contact/contact.component';
import { PagePhotosComponent } from './pages/photos/page-photos.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    NavbarComponent,
    FooterComponent,
    FormContactComponent,
    PhotosComponent,
    PagePhotosComponent,
    LogoComponent,
    ContactComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    MatButtonModule, MatCheckboxModule,
    MatInputModule, MatSelectModule,
    MatInputModule, MatFormFieldModule,
    MatDatepickerModule, MatNativeDateModule,
    MatExpansionModule, MatIconModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [MatDatepickerIntl, HttpClient, {provide: MAT_DATE_LOCALE, useValue: 'pt-BR'}],
  bootstrap: [AppComponent]
})
export class AppModule { }
