import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-photos',
  templateUrl: './photos.component.html',
  styleUrls: ['./photos.component.less']
})
export class PhotosComponent implements OnInit { 

  collections = [
    {
      photo: '../../../assets/imgs/img-1.jpeg'
    },
    {
      photo: '../../../assets/imgs/img-2.jpeg'
    },
    {
      photo: '../../../assets/imgs/img-3.jpeg'
    },
    {
      photo: '../../../assets/imgs/img-4.jpeg'
    },
    {
      photo: '../../../assets/imgs/img-5.jpeg'
    },
    {
      photo: '../../../assets/imgs/img-6.jpeg'
    },
    {
      photo: '../../../assets/imgs/img-7.jpeg'
    },
    {
      photo: '../../../assets/imgs/img-8.jpeg'
    },
    {
      photo: '../../../assets/imgs/img-9.jpeg'
    },
  ];

  constructor() { }

  ngOnInit() {}

}
