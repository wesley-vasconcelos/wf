import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.less']
})
export class NavbarComponent implements OnInit {

  buttonsMenu = [
    {
      button: 'Home',
      link: '/'
    },
    {
      button: 'Fotos',
      link: 'photos'
    },
    {
      button: 'Contato',
      link: 'contact'
    }
  ];

  constructor() { }

  ngOnInit() {
  }

}
