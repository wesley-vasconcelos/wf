import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-contact',
  templateUrl: './form-contact.component.html',
  styleUrls: ['./form-contact.component.less']
})
export class FormContactComponent implements OnInit {
  name: string = '';

  step = 0;

  setStep(index: number) {
    this.step = index;
  }

  nextStep() {
    if (this.name === '') {
      alert('Por favor digite seu nome.');
    } else {
      this.step++;
    }
  }

  prevStep() {
    this.step--;
  }

  constructor() { }

  ngOnInit() {
  }

}
