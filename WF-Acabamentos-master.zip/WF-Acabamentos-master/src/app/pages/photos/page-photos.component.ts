import { Component, OnInit } from '@angular/core';
import { PhotosComponent } from '../../shared/photos/photos.component';

@Component({
  templateUrl: './page-photos.component.html',
  styleUrls: ['./page-photos.component.less']
})
export class PagePhotosComponent implements OnInit {
  constructor() { }

  ngOnInit() {}

}
